<!DOCTYPE html>
<html>
<head>
	<title>profile</title>
</head>
<body>  <table border="">
		<tr colspan=2 >
	    <td><center>profile </center></td>
		</tr>
		<tr>
		<td>Id</td>
		<td>16-10101-2</td>
		</tr>
		<tr>
		<td>Name</td>
		<td>Bob</td>
		</tr>
		<tr>
		<td>USER TYPE</td>
		<td>admin</td>
		</tr>
		<tr colspan=2>
		<td><a href="adminhome.php">Go home</a></td>
		</tr>
		</table>
</body>
</html>