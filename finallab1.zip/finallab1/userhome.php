<?php	
	session_start();
	if(!isset($_SESSION['id'])){  
		header("location: login.php");
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
<table border="">
       <tr>
	   <td>
		<h1>Welcome Anne! </h1>
		<a href="profile.php">profile</a><br>
		<a href="Change.php">change passord</a><br>
		<a href="login.php">logout</a>
		</td>
		</tr>
		</table>
</body>
</html>