<!DOCTYPE html>
<html>
<head>
	<title>user</title>
</head>
<body>  <table border="">
		<tr colspan=2 >
		<td>Users</td>
		</tr>
		<tr>
		<td>Id</td>
		<td>Name</td>
			<td>User TYPE</td>
		</tr>
		<tr>
		<td>15-10101-1</td>
		<td>Bob</td>
		<td>Admin</td>
		</tr>
		<tr>
		<td>16-10102-2</td>
		<td>Anne</td>
		<td>User</td>
		</tr>
		<tr>
		<td>16-10103-2</td>
		<td>Kent</td>
		<td>User</td>
		</tr>
		<tr>
		<td>16-10101</td>
		<td>James</td>
		<td>Admin</td>
		</tr>
		<tr colspan=3>
		<td><a href="userhome.php">Go home</a></td>
		</tr>
	
		</table>
</body>
</html>