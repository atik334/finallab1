<?php	
	session_start();
	if(!isset($_SESSION['id'])){  
		header("location: login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>
</head>
    <body>
    	<center>
	<!--<form action="registration.php" method="post">-->
	<fieldset>
		<legend><h4>Home Page</h4></legend>
	<table border="1" width="30%">
		<tr>
			<td align="center"><a href="adminhome.php">Adminhome</a> </td>
			
		</tr>

		<tr>
			<td align="center"><a href="userhome.php">Userhome</a> </td>
			
		</tr>
		


		<tr>
			<td align="right">
			    <a href="logout.php"><b>Logout</b></a>
			</td>
		</tr>
	</table>
	</fieldset>
</center>
	</form>
